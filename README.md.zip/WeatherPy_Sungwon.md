
# WeatherPy
##### By: Sungwon Byun

### Observable Trends
1. Max temperatures are much colder in the north hemisphere than in the south, while the highest temperatures are just south below the equator. 
2. Looking at the graph of wind speeds, there appears to be two clusters of highs between the equator and the north and south poles.
3. Greatest concentration of humidity resides just south below the equator, while the lowest reside in two clusters between the latitude of 25 and 50 degrees in both north and south.


```python
import pandas as pd
import requests as req
import json
import openweathermapy.core as ow
from datetime import datetime
from citipy import citipy
import random
import matplotlib.pyplot as plt
import seaborn as sns
```


```python
#specify size of your dataset
number_of_cities = 500

key = '7375a9cff89ecc868edf7e60d6d857f8'
#key = '50078a0e7acf496ce521d63c2905a47e'
weather_url = 'http://api.openweathermap.org/data/2.5/weather?'
units = 'imperial'

latitudes = []
longitudes = []
cities = []
countries = []
temperatures = []
humidities = []
wind_speeds = []
cloudiness = []
dates = []
```


```python
#Begin for-loop

print('Beginning data retrieval...')
print('-------------------------------------------------------------------')

#split the randomization of gps coordinates into 4 sections to ensure even distribution
for i in range(number_of_cities):
    
    #while-loop runs while citipy generates a duplicate city or weather data is not available
    placeholder = 1
        
    while placeholder == 1:
        #break apart random generator in 4 to ensure even distribution of worldwide locations
        if i < 125:
            lat = random.random()*90
            long = random.random()*180
        elif i < 250:
            lat = random.random()*90
            long = (random.random()*-180)
        elif i < 375:
            lat = (random.random()*-90)
            long = (random.random()*180)
        else:
            lat = (random.random()*-90)
            long = (random.random()*-180)

        #use citipy to find nearest city from lat/long coordinates
        citipy_city = citipy.nearest_city(lat,long)
        city = citipy_city.city_name
        country = citipy_city.country_code
        
        #make sure no duplicates
        if city in cities:
            placeholder = 1
        else:
            #make sure that the weather data is available
            try:
                #retrieve weather information
                url = weather_url +'q='+city+','+country+'&units='+units+'&APPID='+key
                
                response = req.get(url).json()
                
                temperatures.append(response['main']['temp_max'])
                humidities.append(response['main']['humidity'])
                wind_speeds.append(response['wind']['speed'])
                cloudiness.append(response['clouds']['all'])
                dates.append(response['dt'])
                
                cities.append(city)
                countries.append(country)
                latitudes.append(lat)
                longitudes.append(long)
                
                placeholder = 0
                
                print('Processing Record '+str(i+1)+' | '+ citipy_city.city_name)
                print(url)
                
            except KeyError:
                placeholder = 1

print('Data retrieval: complete!')
print('-------------------------------------------------------------------')plt.scatter(longitudes,latitudes,color='darkblue',s=20)
plt.title('Latitude vs Longitude (12/22/17)')
plt.xlabel('Longitude')
plt.ylabel('Latitude')
plt.show()
```

    Beginning data retrieval...
    -------------------------------------------------------------------
    Processing Record 1 | mehran
    http://api.openweathermap.org/data/2.5/weather?q=mehran,ir&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 2 | belaya gora
    http://api.openweathermap.org/data/2.5/weather?q=belaya gora,ru&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 3 | okha
    http://api.openweathermap.org/data/2.5/weather?q=okha,ru&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 4 | negombo
    http://api.openweathermap.org/data/2.5/weather?q=negombo,lk&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 5 | ust-kuyga
    http://api.openweathermap.org/data/2.5/weather?q=ust-kuyga,ru&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 6 | selyatino
    http://api.openweathermap.org/data/2.5/weather?q=selyatino,ru&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 7 | nalut
    http://api.openweathermap.org/data/2.5/weather?q=nalut,ly&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 8 | soloneshnoye
    http://api.openweathermap.org/data/2.5/weather?q=soloneshnoye,ru&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 9 | zyryanka
    http://api.openweathermap.org/data/2.5/weather?q=zyryanka,ru&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 10 | igrim
    http://api.openweathermap.org/data/2.5/weather?q=igrim,ru&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 11 | novoorsk
    http://api.openweathermap.org/data/2.5/weather?q=novoorsk,ru&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 12 | bintulu
    http://api.openweathermap.org/data/2.5/weather?q=bintulu,my&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 13 | deputatskiy
    http://api.openweathermap.org/data/2.5/weather?q=deputatskiy,ru&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 14 | ust-nera
    http://api.openweathermap.org/data/2.5/weather?q=ust-nera,ru&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 15 | katsuura
    http://api.openweathermap.org/data/2.5/weather?q=katsuura,jp&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 16 | zerbst
    http://api.openweathermap.org/data/2.5/weather?q=zerbst,de&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 17 | shitkino
    http://api.openweathermap.org/data/2.5/weather?q=shitkino,ru&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 18 | mykolayivka
    http://api.openweathermap.org/data/2.5/weather?q=mykolayivka,ua&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 19 | malayal
    http://api.openweathermap.org/data/2.5/weather?q=malayal,ph&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 20 | kavali
    http://api.openweathermap.org/data/2.5/weather?q=kavali,in&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 21 | severo-kurilsk
    http://api.openweathermap.org/data/2.5/weather?q=severo-kurilsk,ru&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 22 | kulhudhuffushi
    http://api.openweathermap.org/data/2.5/weather?q=kulhudhuffushi,mv&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 23 | san isidro
    http://api.openweathermap.org/data/2.5/weather?q=san isidro,ph&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 24 | chernyshevskiy
    http://api.openweathermap.org/data/2.5/weather?q=chernyshevskiy,ru&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 25 | hudiksvall
    http://api.openweathermap.org/data/2.5/weather?q=hudiksvall,se&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 26 | khash
    http://api.openweathermap.org/data/2.5/weather?q=khash,ir&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 27 | teguldet
    http://api.openweathermap.org/data/2.5/weather?q=teguldet,ru&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 28 | chizhou
    http://api.openweathermap.org/data/2.5/weather?q=chizhou,cn&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 29 | jumla
    http://api.openweathermap.org/data/2.5/weather?q=jumla,np&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 30 | svetlyy
    http://api.openweathermap.org/data/2.5/weather?q=svetlyy,ru&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 31 | basoko
    http://api.openweathermap.org/data/2.5/weather?q=basoko,cd&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 32 | oktyabrskoye
    http://api.openweathermap.org/data/2.5/weather?q=oktyabrskoye,ru&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 33 | kharp
    http://api.openweathermap.org/data/2.5/weather?q=kharp,ru&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 34 | ostrovnoy
    http://api.openweathermap.org/data/2.5/weather?q=ostrovnoy,ru&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 35 | akdepe
    http://api.openweathermap.org/data/2.5/weather?q=akdepe,tm&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 36 | dwarka
    http://api.openweathermap.org/data/2.5/weather?q=dwarka,in&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 37 | asyut
    http://api.openweathermap.org/data/2.5/weather?q=asyut,eg&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 38 | tuy hoa
    http://api.openweathermap.org/data/2.5/weather?q=tuy hoa,vn&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 39 | shache
    http://api.openweathermap.org/data/2.5/weather?q=shache,cn&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 40 | fuxin
    http://api.openweathermap.org/data/2.5/weather?q=fuxin,cn&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 41 | novyy urengoy
    http://api.openweathermap.org/data/2.5/weather?q=novyy urengoy,ru&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 42 | buraydah
    http://api.openweathermap.org/data/2.5/weather?q=buraydah,sa&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 43 | tezpur
    http://api.openweathermap.org/data/2.5/weather?q=tezpur,in&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 44 | anadyr
    http://api.openweathermap.org/data/2.5/weather?q=anadyr,ru&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 45 | vysokogornyy
    http://api.openweathermap.org/data/2.5/weather?q=vysokogornyy,ru&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 46 | turukhansk
    http://api.openweathermap.org/data/2.5/weather?q=turukhansk,ru&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 47 | harboore
    http://api.openweathermap.org/data/2.5/weather?q=harboore,dk&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 48 | arys
    http://api.openweathermap.org/data/2.5/weather?q=arys,kz&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 49 | gazojak
    http://api.openweathermap.org/data/2.5/weather?q=gazojak,tm&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 50 | chenzhou
    http://api.openweathermap.org/data/2.5/weather?q=chenzhou,cn&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 51 | tabas
    http://api.openweathermap.org/data/2.5/weather?q=tabas,ir&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 52 | agadez
    http://api.openweathermap.org/data/2.5/weather?q=agadez,ne&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 53 | gorontalo
    http://api.openweathermap.org/data/2.5/weather?q=gorontalo,id&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 54 | dhidhdhoo
    http://api.openweathermap.org/data/2.5/weather?q=dhidhdhoo,mv&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 55 | cingoli
    http://api.openweathermap.org/data/2.5/weather?q=cingoli,it&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 56 | visby
    http://api.openweathermap.org/data/2.5/weather?q=visby,se&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 57 | lakselv
    http://api.openweathermap.org/data/2.5/weather?q=lakselv,no&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 58 | sam chuk
    http://api.openweathermap.org/data/2.5/weather?q=sam chuk,th&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 59 | sibu
    http://api.openweathermap.org/data/2.5/weather?q=sibu,my&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 60 | balabac
    http://api.openweathermap.org/data/2.5/weather?q=balabac,ph&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 61 | gonen
    http://api.openweathermap.org/data/2.5/weather?q=gonen,tr&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 62 | aswan
    http://api.openweathermap.org/data/2.5/weather?q=aswan,eg&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 63 | beidao
    http://api.openweathermap.org/data/2.5/weather?q=beidao,cn&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 64 | vyazemskiy
    http://api.openweathermap.org/data/2.5/weather?q=vyazemskiy,ru&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 65 | susangerd
    http://api.openweathermap.org/data/2.5/weather?q=susangerd,ir&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 66 | longyearbyen
    http://api.openweathermap.org/data/2.5/weather?q=longyearbyen,sj&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 67 | adamovka
    http://api.openweathermap.org/data/2.5/weather?q=adamovka,ru&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 68 | sorong
    http://api.openweathermap.org/data/2.5/weather?q=sorong,id&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 69 | amalapuram
    http://api.openweathermap.org/data/2.5/weather?q=amalapuram,in&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 70 | shenjiamen
    http://api.openweathermap.org/data/2.5/weather?q=shenjiamen,cn&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 71 | shingu
    http://api.openweathermap.org/data/2.5/weather?q=shingu,jp&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 72 | kpalime
    http://api.openweathermap.org/data/2.5/weather?q=kpalime,tg&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 73 | huainan
    http://api.openweathermap.org/data/2.5/weather?q=huainan,cn&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 74 | garwa
    http://api.openweathermap.org/data/2.5/weather?q=garwa,in&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 75 | askarovo
    http://api.openweathermap.org/data/2.5/weather?q=askarovo,ru&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 76 | dalbandin
    http://api.openweathermap.org/data/2.5/weather?q=dalbandin,pk&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 77 | hirara
    http://api.openweathermap.org/data/2.5/weather?q=hirara,jp&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 78 | awjilah
    http://api.openweathermap.org/data/2.5/weather?q=awjilah,ly&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 79 | waddan
    http://api.openweathermap.org/data/2.5/weather?q=waddan,ly&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 80 | kysyl-syr
    http://api.openweathermap.org/data/2.5/weather?q=kysyl-syr,ru&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 81 | bontang
    http://api.openweathermap.org/data/2.5/weather?q=bontang,id&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 82 | pingshan
    http://api.openweathermap.org/data/2.5/weather?q=pingshan,cn&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 83 | gorin
    http://api.openweathermap.org/data/2.5/weather?q=gorin,ru&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 84 | muscat
    http://api.openweathermap.org/data/2.5/weather?q=muscat,om&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 85 | suoyarvi
    http://api.openweathermap.org/data/2.5/weather?q=suoyarvi,ru&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 86 | aizkraukle
    http://api.openweathermap.org/data/2.5/weather?q=aizkraukle,lv&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 87 | aksehir
    http://api.openweathermap.org/data/2.5/weather?q=aksehir,tr&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 88 | genhe
    http://api.openweathermap.org/data/2.5/weather?q=genhe,cn&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 89 | dhariwal
    http://api.openweathermap.org/data/2.5/weather?q=dhariwal,in&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 90 | xining
    http://api.openweathermap.org/data/2.5/weather?q=xining,cn&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 91 | murgab
    http://api.openweathermap.org/data/2.5/weather?q=murgab,tm&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 92 | den helder
    http://api.openweathermap.org/data/2.5/weather?q=den helder,nl&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 93 | wattegama
    http://api.openweathermap.org/data/2.5/weather?q=wattegama,lk&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 94 | dongsheng
    http://api.openweathermap.org/data/2.5/weather?q=dongsheng,cn&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 95 | iskateley
    http://api.openweathermap.org/data/2.5/weather?q=iskateley,ru&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 96 | tonekabon
    http://api.openweathermap.org/data/2.5/weather?q=tonekabon,ir&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 97 | lipova
    http://api.openweathermap.org/data/2.5/weather?q=lipova,ro&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 98 | kaduy
    http://api.openweathermap.org/data/2.5/weather?q=kaduy,ru&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 99 | wagar
    http://api.openweathermap.org/data/2.5/weather?q=wagar,sd&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 100 | kholmogory
    http://api.openweathermap.org/data/2.5/weather?q=kholmogory,ru&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 101 | tibati
    http://api.openweathermap.org/data/2.5/weather?q=tibati,cm&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 102 | gazli
    http://api.openweathermap.org/data/2.5/weather?q=gazli,uz&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 103 | aleksandrovsk-sakhalinskiy
    http://api.openweathermap.org/data/2.5/weather?q=aleksandrovsk-sakhalinskiy,ru&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 104 | kazanskaya
    http://api.openweathermap.org/data/2.5/weather?q=kazanskaya,ru&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 105 | idrinskoye
    http://api.openweathermap.org/data/2.5/weather?q=idrinskoye,ru&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 106 | kodinsk
    http://api.openweathermap.org/data/2.5/weather?q=kodinsk,ru&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 107 | manado
    http://api.openweathermap.org/data/2.5/weather?q=manado,id&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 108 | rafraf
    http://api.openweathermap.org/data/2.5/weather?q=rafraf,tn&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 109 | labuan
    http://api.openweathermap.org/data/2.5/weather?q=labuan,my&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 110 | hovd
    http://api.openweathermap.org/data/2.5/weather?q=hovd,mn&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 111 | komsomolskiy
    http://api.openweathermap.org/data/2.5/weather?q=komsomolskiy,ru&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 112 | kudahuvadhoo
    http://api.openweathermap.org/data/2.5/weather?q=kudahuvadhoo,mv&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 113 | sa kaeo
    http://api.openweathermap.org/data/2.5/weather?q=sa kaeo,th&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 114 | esso
    http://api.openweathermap.org/data/2.5/weather?q=esso,ru&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 115 | monopoli
    http://api.openweathermap.org/data/2.5/weather?q=monopoli,it&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 116 | malaya vishera
    http://api.openweathermap.org/data/2.5/weather?q=malaya vishera,ru&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 117 | turek
    http://api.openweathermap.org/data/2.5/weather?q=turek,pl&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 118 | petropavlovsk-kamchatskiy
    http://api.openweathermap.org/data/2.5/weather?q=petropavlovsk-kamchatskiy,ru&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 119 | liliani
    http://api.openweathermap.org/data/2.5/weather?q=liliani,pk&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 120 | darnah
    http://api.openweathermap.org/data/2.5/weather?q=darnah,ly&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 121 | lengshuitan
    http://api.openweathermap.org/data/2.5/weather?q=lengshuitan,cn&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 122 | itoman
    http://api.openweathermap.org/data/2.5/weather?q=itoman,jp&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 123 | netrakona
    http://api.openweathermap.org/data/2.5/weather?q=netrakona,bd&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 124 | leshukonskoye
    http://api.openweathermap.org/data/2.5/weather?q=leshukonskoye,ru&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 125 | vostok
    http://api.openweathermap.org/data/2.5/weather?q=vostok,ru&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 126 | burgeo
    http://api.openweathermap.org/data/2.5/weather?q=burgeo,ca&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 127 | estelle
    http://api.openweathermap.org/data/2.5/weather?q=estelle,us&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 128 | glendive
    http://api.openweathermap.org/data/2.5/weather?q=glendive,us&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 129 | saint-augustin
    http://api.openweathermap.org/data/2.5/weather?q=saint-augustin,ca&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 130 | lagoa
    http://api.openweathermap.org/data/2.5/weather?q=lagoa,pt&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 131 | burns lake
    http://api.openweathermap.org/data/2.5/weather?q=burns lake,ca&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 132 | nueva guinea
    http://api.openweathermap.org/data/2.5/weather?q=nueva guinea,ni&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 133 | marsh harbour
    http://api.openweathermap.org/data/2.5/weather?q=marsh harbour,bs&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 134 | haines junction
    http://api.openweathermap.org/data/2.5/weather?q=haines junction,ca&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 135 | fresno
    http://api.openweathermap.org/data/2.5/weather?q=fresno,us&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 136 | bahia honda
    http://api.openweathermap.org/data/2.5/weather?q=bahia honda,cu&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 137 | dryden
    http://api.openweathermap.org/data/2.5/weather?q=dryden,ca&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 138 | aberdeen
    http://api.openweathermap.org/data/2.5/weather?q=aberdeen,us&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 139 | ballina
    http://api.openweathermap.org/data/2.5/weather?q=ballina,ie&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 140 | saint-francois
    http://api.openweathermap.org/data/2.5/weather?q=saint-francois,gp&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 141 | cockburn town
    http://api.openweathermap.org/data/2.5/weather?q=cockburn town,bs&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 142 | fort smith
    http://api.openweathermap.org/data/2.5/weather?q=fort smith,us&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 143 | sisimiut
    http://api.openweathermap.org/data/2.5/weather?q=sisimiut,gl&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 144 | dakar
    http://api.openweathermap.org/data/2.5/weather?q=dakar,sn&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 145 | praxedis guerrero
    http://api.openweathermap.org/data/2.5/weather?q=praxedis guerrero,mx&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 146 | rabo de peixe
    http://api.openweathermap.org/data/2.5/weather?q=rabo de peixe,pt&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 147 | redcar
    http://api.openweathermap.org/data/2.5/weather?q=redcar,gb&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 148 | plover
    http://api.openweathermap.org/data/2.5/weather?q=plover,us&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 149 | praia
    http://api.openweathermap.org/data/2.5/weather?q=praia,cv&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 150 | alma
    http://api.openweathermap.org/data/2.5/weather?q=alma,us&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 151 | springfield
    http://api.openweathermap.org/data/2.5/weather?q=springfield,us&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 152 | buchanan
    http://api.openweathermap.org/data/2.5/weather?q=buchanan,lr&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 153 | norman wells
    http://api.openweathermap.org/data/2.5/weather?q=norman wells,ca&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 154 | coos bay
    http://api.openweathermap.org/data/2.5/weather?q=coos bay,us&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 155 | wasilla
    http://api.openweathermap.org/data/2.5/weather?q=wasilla,us&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 156 | nome
    http://api.openweathermap.org/data/2.5/weather?q=nome,us&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 157 | galveston
    http://api.openweathermap.org/data/2.5/weather?q=galveston,us&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 158 | mazagao
    http://api.openweathermap.org/data/2.5/weather?q=mazagao,br&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 159 | teguise
    http://api.openweathermap.org/data/2.5/weather?q=teguise,es&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 160 | boa vista
    http://api.openweathermap.org/data/2.5/weather?q=boa vista,br&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 161 | dire
    http://api.openweathermap.org/data/2.5/weather?q=dire,ml&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 162 | watertown
    http://api.openweathermap.org/data/2.5/weather?q=watertown,us&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 163 | ketchikan
    http://api.openweathermap.org/data/2.5/weather?q=ketchikan,us&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 164 | ucluelet
    http://api.openweathermap.org/data/2.5/weather?q=ucluelet,ca&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 165 | fort nelson
    http://api.openweathermap.org/data/2.5/weather?q=fort nelson,ca&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 166 | montemor-o-novo
    http://api.openweathermap.org/data/2.5/weather?q=montemor-o-novo,pt&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 167 | college
    http://api.openweathermap.org/data/2.5/weather?q=college,us&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 168 | maturin
    http://api.openweathermap.org/data/2.5/weather?q=maturin,ve&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 169 | safford
    http://api.openweathermap.org/data/2.5/weather?q=safford,us&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 170 | wahiawa
    http://api.openweathermap.org/data/2.5/weather?q=wahiawa,us&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 171 | pacific grove
    http://api.openweathermap.org/data/2.5/weather?q=pacific grove,us&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 172 | magnolia
    http://api.openweathermap.org/data/2.5/weather?q=magnolia,us&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 173 | medina
    http://api.openweathermap.org/data/2.5/weather?q=medina,co&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 174 | hearst
    http://api.openweathermap.org/data/2.5/weather?q=hearst,ca&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 175 | westport
    http://api.openweathermap.org/data/2.5/weather?q=westport,ie&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 176 | digby
    http://api.openweathermap.org/data/2.5/weather?q=digby,ca&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 177 | praia da vitoria
    http://api.openweathermap.org/data/2.5/weather?q=praia da vitoria,pt&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 178 | lahaina
    http://api.openweathermap.org/data/2.5/weather?q=lahaina,us&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 179 | anchorage
    http://api.openweathermap.org/data/2.5/weather?q=anchorage,us&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 180 | pittsfield
    http://api.openweathermap.org/data/2.5/weather?q=pittsfield,us&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 181 | san sebastian
    http://api.openweathermap.org/data/2.5/weather?q=san sebastian,sv&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 182 | aguililla
    http://api.openweathermap.org/data/2.5/weather?q=aguililla,mx&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 183 | puerto carreno
    http://api.openweathermap.org/data/2.5/weather?q=puerto carreno,co&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 184 | flagstaff
    http://api.openweathermap.org/data/2.5/weather?q=flagstaff,us&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 185 | cocorit
    http://api.openweathermap.org/data/2.5/weather?q=cocorit,mx&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 186 | smithers
    http://api.openweathermap.org/data/2.5/weather?q=smithers,ca&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 187 | clarence town
    http://api.openweathermap.org/data/2.5/weather?q=clarence town,bs&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 188 | santa cruz
    http://api.openweathermap.org/data/2.5/weather?q=santa cruz,cr&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 189 | manta
    http://api.openweathermap.org/data/2.5/weather?q=manta,ec&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 190 | okmulgee
    http://api.openweathermap.org/data/2.5/weather?q=okmulgee,us&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 191 | la cruz
    http://api.openweathermap.org/data/2.5/weather?q=la cruz,mx&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 192 | kewanee
    http://api.openweathermap.org/data/2.5/weather?q=kewanee,us&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 193 | colares
    http://api.openweathermap.org/data/2.5/weather?q=colares,pt&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 194 | ponta delgada
    http://api.openweathermap.org/data/2.5/weather?q=ponta delgada,pt&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 195 | inuvik
    http://api.openweathermap.org/data/2.5/weather?q=inuvik,ca&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 196 | elizabeth city
    http://api.openweathermap.org/data/2.5/weather?q=elizabeth city,us&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 197 | claremorris
    http://api.openweathermap.org/data/2.5/weather?q=claremorris,ie&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 198 | iqaluit
    http://api.openweathermap.org/data/2.5/weather?q=iqaluit,ca&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 199 | inirida
    http://api.openweathermap.org/data/2.5/weather?q=inirida,co&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 200 | key biscayne
    http://api.openweathermap.org/data/2.5/weather?q=key biscayne,us&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 201 | prince rupert
    http://api.openweathermap.org/data/2.5/weather?q=prince rupert,ca&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 202 | miles city
    http://api.openweathermap.org/data/2.5/weather?q=miles city,us&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 203 | aljezur
    http://api.openweathermap.org/data/2.5/weather?q=aljezur,pt&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 204 | ixtapa
    http://api.openweathermap.org/data/2.5/weather?q=ixtapa,mx&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 205 | saint-pierre
    http://api.openweathermap.org/data/2.5/weather?q=saint-pierre,pm&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 206 | pascagoula
    http://api.openweathermap.org/data/2.5/weather?q=pascagoula,us&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 207 | koutiala
    http://api.openweathermap.org/data/2.5/weather?q=koutiala,ml&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 208 | venezuela
    http://api.openweathermap.org/data/2.5/weather?q=venezuela,cu&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 209 | beckley
    http://api.openweathermap.org/data/2.5/weather?q=beckley,us&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 210 | mayo
    http://api.openweathermap.org/data/2.5/weather?q=mayo,ca&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 211 | atar
    http://api.openweathermap.org/data/2.5/weather?q=atar,mr&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 212 | marysville
    http://api.openweathermap.org/data/2.5/weather?q=marysville,us&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 213 | half moon bay
    http://api.openweathermap.org/data/2.5/weather?q=half moon bay,us&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 214 | diofior
    http://api.openweathermap.org/data/2.5/weather?q=diofior,sn&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 215 | ziniare
    http://api.openweathermap.org/data/2.5/weather?q=ziniare,bf&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 216 | athabasca
    http://api.openweathermap.org/data/2.5/weather?q=athabasca,ca&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 217 | lagos de moreno
    http://api.openweathermap.org/data/2.5/weather?q=lagos de moreno,mx&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 218 | orchard homes
    http://api.openweathermap.org/data/2.5/weather?q=orchard homes,us&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 219 | pedasi
    http://api.openweathermap.org/data/2.5/weather?q=pedasi,pa&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 220 | monrovia
    http://api.openweathermap.org/data/2.5/weather?q=monrovia,lr&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 221 | havre-saint-pierre
    http://api.openweathermap.org/data/2.5/weather?q=havre-saint-pierre,ca&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 222 | etchoropo
    http://api.openweathermap.org/data/2.5/weather?q=etchoropo,mx&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 223 | waverly
    http://api.openweathermap.org/data/2.5/weather?q=waverly,us&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 224 | douglas
    http://api.openweathermap.org/data/2.5/weather?q=douglas,us&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 225 | hailey
    http://api.openweathermap.org/data/2.5/weather?q=hailey,us&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 226 | stettler
    http://api.openweathermap.org/data/2.5/weather?q=stettler,ca&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 227 | liverpool
    http://api.openweathermap.org/data/2.5/weather?q=liverpool,ca&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 228 | vestmannaeyjar
    http://api.openweathermap.org/data/2.5/weather?q=vestmannaeyjar,is&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 229 | fairbanks
    http://api.openweathermap.org/data/2.5/weather?q=fairbanks,us&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 230 | evanston
    http://api.openweathermap.org/data/2.5/weather?q=evanston,us&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 231 | massena
    http://api.openweathermap.org/data/2.5/weather?q=massena,us&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 232 | puerto madero
    http://api.openweathermap.org/data/2.5/weather?q=puerto madero,mx&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 233 | arrifes
    http://api.openweathermap.org/data/2.5/weather?q=arrifes,pt&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 234 | hurricane
    http://api.openweathermap.org/data/2.5/weather?q=hurricane,us&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 235 | akureyri
    http://api.openweathermap.org/data/2.5/weather?q=akureyri,is&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 236 | palmer
    http://api.openweathermap.org/data/2.5/weather?q=palmer,us&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 237 | greenville
    http://api.openweathermap.org/data/2.5/weather?q=greenville,us&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 238 | bournemouth
    http://api.openweathermap.org/data/2.5/weather?q=bournemouth,gb&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 239 | empalme
    http://api.openweathermap.org/data/2.5/weather?q=empalme,mx&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 240 | san quintin
    http://api.openweathermap.org/data/2.5/weather?q=san quintin,mx&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 241 | kapuskasing
    http://api.openweathermap.org/data/2.5/weather?q=kapuskasing,ca&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 242 | kitimat
    http://api.openweathermap.org/data/2.5/weather?q=kitimat,ca&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 243 | pullman
    http://api.openweathermap.org/data/2.5/weather?q=pullman,us&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 244 | soto la marina
    http://api.openweathermap.org/data/2.5/weather?q=soto la marina,mx&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 245 | dalvik
    http://api.openweathermap.org/data/2.5/weather?q=dalvik,is&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 246 | helena
    http://api.openweathermap.org/data/2.5/weather?q=helena,us&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 247 | pemberton
    http://api.openweathermap.org/data/2.5/weather?q=pemberton,ca&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 248 | pamplona
    http://api.openweathermap.org/data/2.5/weather?q=pamplona,es&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 249 | cape girardeau
    http://api.openweathermap.org/data/2.5/weather?q=cape girardeau,us&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 250 | oistins
    http://api.openweathermap.org/data/2.5/weather?q=oistins,bb&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 251 | senanga
    http://api.openweathermap.org/data/2.5/weather?q=senanga,zm&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 252 | mwingi
    http://api.openweathermap.org/data/2.5/weather?q=mwingi,ke&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 253 | sinazongwe
    http://api.openweathermap.org/data/2.5/weather?q=sinazongwe,zm&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 254 | broome
    http://api.openweathermap.org/data/2.5/weather?q=broome,au&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 255 | mombasa
    http://api.openweathermap.org/data/2.5/weather?q=mombasa,ke&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 256 | nelson bay
    http://api.openweathermap.org/data/2.5/weather?q=nelson bay,au&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 257 | saint-joseph
    http://api.openweathermap.org/data/2.5/weather?q=saint-joseph,re&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 258 | luanda
    http://api.openweathermap.org/data/2.5/weather?q=luanda,ao&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 259 | yulara
    http://api.openweathermap.org/data/2.5/weather?q=yulara,au&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 260 | nampula
    http://api.openweathermap.org/data/2.5/weather?q=nampula,mz&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 261 | samarinda
    http://api.openweathermap.org/data/2.5/weather?q=samarinda,id&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 262 | belfast
    http://api.openweathermap.org/data/2.5/weather?q=belfast,za&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 263 | ahipara
    http://api.openweathermap.org/data/2.5/weather?q=ahipara,nz&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 264 | maputo
    http://api.openweathermap.org/data/2.5/weather?q=maputo,mz&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 265 | manokwari
    http://api.openweathermap.org/data/2.5/weather?q=manokwari,id&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 266 | saint-leu
    http://api.openweathermap.org/data/2.5/weather?q=saint-leu,re&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 267 | labuhan
    http://api.openweathermap.org/data/2.5/weather?q=labuhan,id&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 268 | metro
    http://api.openweathermap.org/data/2.5/weather?q=metro,id&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 269 | boyolangu
    http://api.openweathermap.org/data/2.5/weather?q=boyolangu,id&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 270 | madang
    http://api.openweathermap.org/data/2.5/weather?q=madang,pg&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 271 | te anau
    http://api.openweathermap.org/data/2.5/weather?q=te anau,nz&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 272 | grand gaube
    http://api.openweathermap.org/data/2.5/weather?q=grand gaube,mu&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 273 | inhambane
    http://api.openweathermap.org/data/2.5/weather?q=inhambane,mz&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 274 | bambanglipuro
    http://api.openweathermap.org/data/2.5/weather?q=bambanglipuro,id&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 275 | kokstad
    http://api.openweathermap.org/data/2.5/weather?q=kokstad,za&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 276 | chinsali
    http://api.openweathermap.org/data/2.5/weather?q=chinsali,zm&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 277 | beloha
    http://api.openweathermap.org/data/2.5/weather?q=beloha,mg&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 278 | hokitika
    http://api.openweathermap.org/data/2.5/weather?q=hokitika,nz&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 279 | lumeje
    http://api.openweathermap.org/data/2.5/weather?q=lumeje,ao&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 280 | gold coast
    http://api.openweathermap.org/data/2.5/weather?q=gold coast,au&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 281 | kiunga
    http://api.openweathermap.org/data/2.5/weather?q=kiunga,pg&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 282 | kasempa
    http://api.openweathermap.org/data/2.5/weather?q=kasempa,zm&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 283 | southbridge
    http://api.openweathermap.org/data/2.5/weather?q=southbridge,nz&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 284 | malanje
    http://api.openweathermap.org/data/2.5/weather?q=malanje,ao&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 285 | matongo
    http://api.openweathermap.org/data/2.5/weather?q=matongo,tz&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 286 | tolaga bay
    http://api.openweathermap.org/data/2.5/weather?q=tolaga bay,nz&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 287 | lucapa
    http://api.openweathermap.org/data/2.5/weather?q=lucapa,ao&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 288 | launceston
    http://api.openweathermap.org/data/2.5/weather?q=launceston,au&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 289 | bukama
    http://api.openweathermap.org/data/2.5/weather?q=bukama,cd&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 290 | northam
    http://api.openweathermap.org/data/2.5/weather?q=northam,au&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 291 | nosy varika
    http://api.openweathermap.org/data/2.5/weather?q=nosy varika,mg&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 292 | ayr
    http://api.openweathermap.org/data/2.5/weather?q=ayr,au&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 293 | huambo
    http://api.openweathermap.org/data/2.5/weather?q=huambo,ao&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 294 | singaraja
    http://api.openweathermap.org/data/2.5/weather?q=singaraja,id&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 295 | mahajanga
    http://api.openweathermap.org/data/2.5/weather?q=mahajanga,mg&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 296 | voi
    http://api.openweathermap.org/data/2.5/weather?q=voi,ke&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 297 | waipawa
    http://api.openweathermap.org/data/2.5/weather?q=waipawa,nz&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 298 | ruteng
    http://api.openweathermap.org/data/2.5/weather?q=ruteng,id&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 299 | banjar
    http://api.openweathermap.org/data/2.5/weather?q=banjar,id&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 300 | mzimba
    http://api.openweathermap.org/data/2.5/weather?q=mzimba,mw&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 301 | kabalo
    http://api.openweathermap.org/data/2.5/weather?q=kabalo,cd&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 302 | tanga
    http://api.openweathermap.org/data/2.5/weather?q=tanga,tz&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 303 | koumac
    http://api.openweathermap.org/data/2.5/weather?q=koumac,nc&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 304 | pangkalanbuun
    http://api.openweathermap.org/data/2.5/weather?q=pangkalanbuun,id&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 305 | ambon
    http://api.openweathermap.org/data/2.5/weather?q=ambon,id&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 306 | daru
    http://api.openweathermap.org/data/2.5/weather?q=daru,pg&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 307 | maumere
    http://api.openweathermap.org/data/2.5/weather?q=maumere,id&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 308 | lambarene
    http://api.openweathermap.org/data/2.5/weather?q=lambarene,ga&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 309 | angoram
    http://api.openweathermap.org/data/2.5/weather?q=angoram,pg&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 310 | uige
    http://api.openweathermap.org/data/2.5/weather?q=uige,ao&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 311 | salazie
    http://api.openweathermap.org/data/2.5/weather?q=salazie,re&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 312 | kawalu
    http://api.openweathermap.org/data/2.5/weather?q=kawalu,id&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 313 | quatre cocos
    http://api.openweathermap.org/data/2.5/weather?q=quatre cocos,mu&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 314 | kinango
    http://api.openweathermap.org/data/2.5/weather?q=kinango,ke&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 315 | roma
    http://api.openweathermap.org/data/2.5/weather?q=roma,au&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 316 | shakawe
    http://api.openweathermap.org/data/2.5/weather?q=shakawe,bw&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 317 | knysna
    http://api.openweathermap.org/data/2.5/weather?q=knysna,za&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 318 | zomba
    http://api.openweathermap.org/data/2.5/weather?q=zomba,mw&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 319 | dedza
    http://api.openweathermap.org/data/2.5/weather?q=dedza,mw&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 320 | bururi
    http://api.openweathermap.org/data/2.5/weather?q=bururi,bi&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 321 | kibaya
    http://api.openweathermap.org/data/2.5/weather?q=kibaya,tz&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 322 | siteki
    http://api.openweathermap.org/data/2.5/weather?q=siteki,sz&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 323 | moree
    http://api.openweathermap.org/data/2.5/weather?q=moree,au&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 324 | port hedland
    http://api.openweathermap.org/data/2.5/weather?q=port hedland,au&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 325 | plettenberg bay
    http://api.openweathermap.org/data/2.5/weather?q=plettenberg bay,za&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 326 | port augusta
    http://api.openweathermap.org/data/2.5/weather?q=port augusta,au&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 327 | cairns
    http://api.openweathermap.org/data/2.5/weather?q=cairns,au&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 328 | middelburg
    http://api.openweathermap.org/data/2.5/weather?q=middelburg,za&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 329 | ndjole
    http://api.openweathermap.org/data/2.5/weather?q=ndjole,ga&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 330 | vao
    http://api.openweathermap.org/data/2.5/weather?q=vao,nc&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 331 | calvinia
    http://api.openweathermap.org/data/2.5/weather?q=calvinia,za&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 332 | coolum beach
    http://api.openweathermap.org/data/2.5/weather?q=coolum beach,au&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 333 | komatipoort
    http://api.openweathermap.org/data/2.5/weather?q=komatipoort,za&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 334 | cootamundra
    http://api.openweathermap.org/data/2.5/weather?q=cootamundra,au&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 335 | tsumeb
    http://api.openweathermap.org/data/2.5/weather?q=tsumeb,na&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 336 | mayumba
    http://api.openweathermap.org/data/2.5/weather?q=mayumba,ga&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 337 | wanaka
    http://api.openweathermap.org/data/2.5/weather?q=wanaka,nz&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 338 | empangeni
    http://api.openweathermap.org/data/2.5/weather?q=empangeni,za&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 339 | kyabram
    http://api.openweathermap.org/data/2.5/weather?q=kyabram,au&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 340 | cooma
    http://api.openweathermap.org/data/2.5/weather?q=cooma,au&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 341 | lubumbashi
    http://api.openweathermap.org/data/2.5/weather?q=lubumbashi,cd&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 342 | inongo
    http://api.openweathermap.org/data/2.5/weather?q=inongo,cd&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 343 | narok
    http://api.openweathermap.org/data/2.5/weather?q=narok,ke&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 344 | montepuez
    http://api.openweathermap.org/data/2.5/weather?q=montepuez,mz&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 345 | lusambo
    http://api.openweathermap.org/data/2.5/weather?q=lusambo,cd&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 346 | lukulu
    http://api.openweathermap.org/data/2.5/weather?q=lukulu,zm&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 347 | dondo
    http://api.openweathermap.org/data/2.5/weather?q=dondo,mz&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 348 | innisfail
    http://api.openweathermap.org/data/2.5/weather?q=innisfail,au&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 349 | arandis
    http://api.openweathermap.org/data/2.5/weather?q=arandis,na&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 350 | kendari
    http://api.openweathermap.org/data/2.5/weather?q=kendari,id&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 351 | sokoni
    http://api.openweathermap.org/data/2.5/weather?q=sokoni,tz&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 352 | ambovombe
    http://api.openweathermap.org/data/2.5/weather?q=ambovombe,mg&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 353 | molteno
    http://api.openweathermap.org/data/2.5/weather?q=molteno,za&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 354 | pouebo
    http://api.openweathermap.org/data/2.5/weather?q=pouebo,nc&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 355 | mwaro
    http://api.openweathermap.org/data/2.5/weather?q=mwaro,bi&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 356 | kitui
    http://api.openweathermap.org/data/2.5/weather?q=kitui,ke&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 357 | burnie
    http://api.openweathermap.org/data/2.5/weather?q=burnie,au&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 358 | kasangulu
    http://api.openweathermap.org/data/2.5/weather?q=kasangulu,cd&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 359 | omboue
    http://api.openweathermap.org/data/2.5/weather?q=omboue,ga&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 360 | karibib
    http://api.openweathermap.org/data/2.5/weather?q=karibib,na&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 361 | gobabis
    http://api.openweathermap.org/data/2.5/weather?q=gobabis,na&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 362 | chimoio
    http://api.openweathermap.org/data/2.5/weather?q=chimoio,mz&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 363 | honiara
    http://api.openweathermap.org/data/2.5/weather?q=honiara,sb&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 364 | oranjemund
    http://api.openweathermap.org/data/2.5/weather?q=oranjemund,na&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 365 | chake chake
    http://api.openweathermap.org/data/2.5/weather?q=chake chake,tz&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 366 | moanda
    http://api.openweathermap.org/data/2.5/weather?q=moanda,ga&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 367 | swan hill
    http://api.openweathermap.org/data/2.5/weather?q=swan hill,au&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 368 | pontianak
    http://api.openweathermap.org/data/2.5/weather?q=pontianak,id&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 369 | sakaraha
    http://api.openweathermap.org/data/2.5/weather?q=sakaraha,mg&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 370 | nabire
    http://api.openweathermap.org/data/2.5/weather?q=nabire,id&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 371 | xai-xai
    http://api.openweathermap.org/data/2.5/weather?q=xai-xai,mz&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 372 | kasane
    http://api.openweathermap.org/data/2.5/weather?q=kasane,bw&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 373 | charters towers
    http://api.openweathermap.org/data/2.5/weather?q=charters towers,au&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 374 | umkomaas
    http://api.openweathermap.org/data/2.5/weather?q=umkomaas,za&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 375 | kandrian
    http://api.openweathermap.org/data/2.5/weather?q=kandrian,pg&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 376 | camapua
    http://api.openweathermap.org/data/2.5/weather?q=camapua,br&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 377 | constitucion
    http://api.openweathermap.org/data/2.5/weather?q=constitucion,cl&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 378 | pangoa
    http://api.openweathermap.org/data/2.5/weather?q=pangoa,pe&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 379 | talara
    http://api.openweathermap.org/data/2.5/weather?q=talara,pe&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 380 | luis correia
    http://api.openweathermap.org/data/2.5/weather?q=luis correia,br&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 381 | senador pompeu
    http://api.openweathermap.org/data/2.5/weather?q=senador pompeu,br&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 382 | itapirapua
    http://api.openweathermap.org/data/2.5/weather?q=itapirapua,br&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 383 | sao luiz gonzaga
    http://api.openweathermap.org/data/2.5/weather?q=sao luiz gonzaga,br&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 384 | pauini
    http://api.openweathermap.org/data/2.5/weather?q=pauini,br&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 385 | linhares
    http://api.openweathermap.org/data/2.5/weather?q=linhares,br&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 386 | sechura
    http://api.openweathermap.org/data/2.5/weather?q=sechura,pe&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 387 | maceio
    http://api.openweathermap.org/data/2.5/weather?q=maceio,br&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 388 | puerto madryn
    http://api.openweathermap.org/data/2.5/weather?q=puerto madryn,ar&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 389 | coari
    http://api.openweathermap.org/data/2.5/weather?q=coari,br&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 390 | puerto leguizamo
    http://api.openweathermap.org/data/2.5/weather?q=puerto leguizamo,co&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 391 | pinheiro machado
    http://api.openweathermap.org/data/2.5/weather?q=pinheiro machado,br&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 392 | jatai
    http://api.openweathermap.org/data/2.5/weather?q=jatai,br&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 393 | presidencia roque saenz pena
    http://api.openweathermap.org/data/2.5/weather?q=presidencia roque saenz pena,ar&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 394 | camiri
    http://api.openweathermap.org/data/2.5/weather?q=camiri,bo&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 395 | trelew
    http://api.openweathermap.org/data/2.5/weather?q=trelew,ar&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 396 | chimbote
    http://api.openweathermap.org/data/2.5/weather?q=chimbote,pe&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 397 | santo antonio do ica
    http://api.openweathermap.org/data/2.5/weather?q=santo antonio do ica,br&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 398 | venancio aires
    http://api.openweathermap.org/data/2.5/weather?q=venancio aires,br&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 399 | ilave
    http://api.openweathermap.org/data/2.5/weather?q=ilave,pe&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 400 | taltal
    http://api.openweathermap.org/data/2.5/weather?q=taltal,cl&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 401 | palmeiras de goias
    http://api.openweathermap.org/data/2.5/weather?q=palmeiras de goias,br&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 402 | pimenta bueno
    http://api.openweathermap.org/data/2.5/weather?q=pimenta bueno,br&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 403 | itacarambi
    http://api.openweathermap.org/data/2.5/weather?q=itacarambi,br&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 404 | young
    http://api.openweathermap.org/data/2.5/weather?q=young,uy&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 405 | huayucachi
    http://api.openweathermap.org/data/2.5/weather?q=huayucachi,pe&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 406 | jose de freitas
    http://api.openweathermap.org/data/2.5/weather?q=jose de freitas,br&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 407 | cerrito
    http://api.openweathermap.org/data/2.5/weather?q=cerrito,py&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 408 | presidente dutra
    http://api.openweathermap.org/data/2.5/weather?q=presidente dutra,br&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 409 | paramirim
    http://api.openweathermap.org/data/2.5/weather?q=paramirim,br&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 410 | vaitape
    http://api.openweathermap.org/data/2.5/weather?q=vaitape,pf&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 411 | humaita
    http://api.openweathermap.org/data/2.5/weather?q=humaita,br&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 412 | neuquen
    http://api.openweathermap.org/data/2.5/weather?q=neuquen,ar&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 413 | porto nacional
    http://api.openweathermap.org/data/2.5/weather?q=porto nacional,br&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 414 | natal
    http://api.openweathermap.org/data/2.5/weather?q=natal,br&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 415 | conceicao do araguaia
    http://api.openweathermap.org/data/2.5/weather?q=conceicao do araguaia,br&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 416 | auriflama
    http://api.openweathermap.org/data/2.5/weather?q=auriflama,br&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 417 | pimentel
    http://api.openweathermap.org/data/2.5/weather?q=pimentel,pe&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 418 | ladario
    http://api.openweathermap.org/data/2.5/weather?q=ladario,br&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 419 | guayaramerin
    http://api.openweathermap.org/data/2.5/weather?q=guayaramerin,bo&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 420 | bermejo
    http://api.openweathermap.org/data/2.5/weather?q=bermejo,bo&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 421 | malacacheta
    http://api.openweathermap.org/data/2.5/weather?q=malacacheta,br&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 422 | assare
    http://api.openweathermap.org/data/2.5/weather?q=assare,br&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 423 | villarrica
    http://api.openweathermap.org/data/2.5/weather?q=villarrica,cl&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 424 | pontes e lacerda
    http://api.openweathermap.org/data/2.5/weather?q=pontes e lacerda,br&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 425 | huancavelica
    http://api.openweathermap.org/data/2.5/weather?q=huancavelica,pe&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 426 | anori
    http://api.openweathermap.org/data/2.5/weather?q=anori,br&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 427 | mapiri
    http://api.openweathermap.org/data/2.5/weather?q=mapiri,bo&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 428 | tevaitoa
    http://api.openweathermap.org/data/2.5/weather?q=tevaitoa,pf&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 429 | tucurui
    http://api.openweathermap.org/data/2.5/weather?q=tucurui,br&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 430 | pocoes
    http://api.openweathermap.org/data/2.5/weather?q=pocoes,br&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 431 | sao paulo de olivenca
    http://api.openweathermap.org/data/2.5/weather?q=sao paulo de olivenca,br&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 432 | riachao do jacuipe
    http://api.openweathermap.org/data/2.5/weather?q=riachao do jacuipe,br&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 433 | guiratinga
    http://api.openweathermap.org/data/2.5/weather?q=guiratinga,br&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 434 | villa constitucion
    http://api.openweathermap.org/data/2.5/weather?q=villa constitucion,ar&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 435 | la paz
    http://api.openweathermap.org/data/2.5/weather?q=la paz,bo&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 436 | reconquista
    http://api.openweathermap.org/data/2.5/weather?q=reconquista,ar&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 437 | zorritos
    http://api.openweathermap.org/data/2.5/weather?q=zorritos,pe&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 438 | haapiti
    http://api.openweathermap.org/data/2.5/weather?q=haapiti,pf&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 439 | juquia
    http://api.openweathermap.org/data/2.5/weather?q=juquia,br&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 440 | barra dos coqueiros
    http://api.openweathermap.org/data/2.5/weather?q=barra dos coqueiros,br&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 441 | borba
    http://api.openweathermap.org/data/2.5/weather?q=borba,br&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 442 | sao jose da coroa grande
    http://api.openweathermap.org/data/2.5/weather?q=sao jose da coroa grande,br&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 443 | vera cruz
    http://api.openweathermap.org/data/2.5/weather?q=vera cruz,br&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 444 | illapel
    http://api.openweathermap.org/data/2.5/weather?q=illapel,cl&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 445 | san pedro de ycuamandiyu
    http://api.openweathermap.org/data/2.5/weather?q=san pedro de ycuamandiyu,py&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 446 | monte alegre
    http://api.openweathermap.org/data/2.5/weather?q=monte alegre,br&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 447 | poco verde
    http://api.openweathermap.org/data/2.5/weather?q=poco verde,br&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 448 | sao miguel do araguaia
    http://api.openweathermap.org/data/2.5/weather?q=sao miguel do araguaia,br&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 449 | campestre
    http://api.openweathermap.org/data/2.5/weather?q=campestre,br&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 450 | itaituba
    http://api.openweathermap.org/data/2.5/weather?q=itaituba,br&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 451 | san carlos de bariloche
    http://api.openweathermap.org/data/2.5/weather?q=san carlos de bariloche,ar&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 452 | puerto narino
    http://api.openweathermap.org/data/2.5/weather?q=puerto narino,co&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 453 | canarana
    http://api.openweathermap.org/data/2.5/weather?q=canarana,br&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 454 | tonantins
    http://api.openweathermap.org/data/2.5/weather?q=tonantins,br&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 455 | caranavi
    http://api.openweathermap.org/data/2.5/weather?q=caranavi,bo&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 456 | oriximina
    http://api.openweathermap.org/data/2.5/weather?q=oriximina,br&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 457 | cordoba
    http://api.openweathermap.org/data/2.5/weather?q=cordoba,ar&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 458 | laje
    http://api.openweathermap.org/data/2.5/weather?q=laje,br&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 459 | la oroya
    http://api.openweathermap.org/data/2.5/weather?q=la oroya,pe&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 460 | bell ville
    http://api.openweathermap.org/data/2.5/weather?q=bell ville,ar&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 461 | colomi
    http://api.openweathermap.org/data/2.5/weather?q=colomi,bo&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 462 | huaral
    http://api.openweathermap.org/data/2.5/weather?q=huaral,pe&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 463 | gualaquiza
    http://api.openweathermap.org/data/2.5/weather?q=gualaquiza,ec&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 464 | placido de castro
    http://api.openweathermap.org/data/2.5/weather?q=placido de castro,br&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 465 | carauari
    http://api.openweathermap.org/data/2.5/weather?q=carauari,br&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 466 | paita
    http://api.openweathermap.org/data/2.5/weather?q=paita,pe&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 467 | teahupoo
    http://api.openweathermap.org/data/2.5/weather?q=teahupoo,pf&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 468 | desaguadero
    http://api.openweathermap.org/data/2.5/weather?q=desaguadero,pe&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 469 | manhumirim
    http://api.openweathermap.org/data/2.5/weather?q=manhumirim,br&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 470 | conceicao das alagoas
    http://api.openweathermap.org/data/2.5/weather?q=conceicao das alagoas,br&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 471 | buritis
    http://api.openweathermap.org/data/2.5/weather?q=buritis,br&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 472 | encantado
    http://api.openweathermap.org/data/2.5/weather?q=encantado,br&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 473 | copiapo
    http://api.openweathermap.org/data/2.5/weather?q=copiapo,cl&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 474 | general roca
    http://api.openweathermap.org/data/2.5/weather?q=general roca,ar&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 475 | iquitos
    http://api.openweathermap.org/data/2.5/weather?q=iquitos,pe&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 476 | salinopolis
    http://api.openweathermap.org/data/2.5/weather?q=salinopolis,br&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 477 | mancio lima
    http://api.openweathermap.org/data/2.5/weather?q=mancio lima,br&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 478 | porto velho
    http://api.openweathermap.org/data/2.5/weather?q=porto velho,br&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 479 | seabra
    http://api.openweathermap.org/data/2.5/weather?q=seabra,br&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 480 | boa esperanca
    http://api.openweathermap.org/data/2.5/weather?q=boa esperanca,br&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 481 | brasilia
    http://api.openweathermap.org/data/2.5/weather?q=brasilia,br&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 482 | lazaro cardenas
    http://api.openweathermap.org/data/2.5/weather?q=lazaro cardenas,mx&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 483 | san cosme y damian
    http://api.openweathermap.org/data/2.5/weather?q=san cosme y damian,py&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 484 | grand-lahou
    http://api.openweathermap.org/data/2.5/weather?q=grand-lahou,ci&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 485 | sao paulo do potengi
    http://api.openweathermap.org/data/2.5/weather?q=sao paulo do potengi,br&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 486 | santiago del estero
    http://api.openweathermap.org/data/2.5/weather?q=santiago del estero,ar&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 487 | vilcun
    http://api.openweathermap.org/data/2.5/weather?q=vilcun,cl&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 488 | belmonte
    http://api.openweathermap.org/data/2.5/weather?q=belmonte,br&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 489 | sao francisco de paula
    http://api.openweathermap.org/data/2.5/weather?q=sao francisco de paula,br&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 490 | santana do livramento
    http://api.openweathermap.org/data/2.5/weather?q=santana do livramento,br&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 491 | bom despacho
    http://api.openweathermap.org/data/2.5/weather?q=bom despacho,br&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 492 | coruripe
    http://api.openweathermap.org/data/2.5/weather?q=coruripe,br&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 493 | carangola
    http://api.openweathermap.org/data/2.5/weather?q=carangola,br&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 494 | sao felix do xingu
    http://api.openweathermap.org/data/2.5/weather?q=sao felix do xingu,br&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 495 | puerto quijarro
    http://api.openweathermap.org/data/2.5/weather?q=puerto quijarro,bo&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 496 | nueva loja
    http://api.openweathermap.org/data/2.5/weather?q=nueva loja,ec&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 497 | pangai
    http://api.openweathermap.org/data/2.5/weather?q=pangai,to&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 498 | itaqui
    http://api.openweathermap.org/data/2.5/weather?q=itaqui,br&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 499 | brasilia de minas
    http://api.openweathermap.org/data/2.5/weather?q=brasilia de minas,br&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Processing Record 500 | maracai
    http://api.openweathermap.org/data/2.5/weather?q=maracai,br&units=imperial&APPID=7375a9cff89ecc868edf7e60d6d857f8
    Data retrieval: complete!
    -------------------------------------------------------------------
    


```python
#check whether cities are evenly distributed or clumped
plt.scatter(longitudes,latitudes,color='darkblue',s=20)
plt.title('Latitude vs Longitude (12/22/17)')
plt.xlabel('Longitude')
plt.ylabel('Latitude')
plt.show()
```


![png](output_4_0.png)



```python
#create dataframe for retrieved data
df = pd.DataFrame({'City':cities,
                   'Cloudiness':cloudiness,
                   'Country':countries,
                   'Date':dates,
                   'Humidity':humidities,
                   'Lat':latitudes,
                   'Lng':longitudes,
                   'Max Temp':temperatures,
                   'Wind Speed':wind_speeds})

df.to_csv('City_Data')
```


```python
#set seaborn
sns.set()

plt.scatter(latitudes,temperatures,color='darkblue',s=20)
plt.title('City Latitude vs Temperature (12/22/17)')
plt.xlabel('Latitude')
plt.ylabel('Temperature (F)')
plt.xlim(-100,100)
plt.ylim(-80,120)
plt.show()
```


![png](output_6_0.png)



```python
plt.scatter(latitudes,humidities,color='darkblue',s=20)
plt.title('City Latitude vs Humidity (12/22/17)')
plt.xlabel('Latitude')
plt.ylabel('Humidity (%)')
plt.xlim(-100,100)
plt.ylim(-20,120)
plt.show()
```


![png](output_7_0.png)



```python
plt.scatter(latitudes,wind_speeds,color='darkblue',s=20)
plt.title('City Latitude vs Wind Speed (12/22/17)')
plt.xlabel('Latitude')
plt.ylabel('Wind Speed (mph)')
plt.xlim(-100,100)
plt.ylim(-5,40)
plt.show()
```


![png](output_8_0.png)



```python
plt.scatter(latitudes,cloudiness,color='darkblue',s=20)
plt.title('City Latitude vs Cloudiness (12/22/17)')
plt.xlabel('Latitude')
plt.ylabel('Cloudiness (%)')
plt.xlim(-100,100)
plt.ylim(-20,120)
plt.show()
```


![png](output_9_0.png)

